$(document).ready(function(){
    // Embed YouTube videos
    $('a[href*=".youtube.com"]').viewbox({
        widthWindow: 900
    });
});