# -*- coding: utf-8 -*-

#from django.contrib import admin
#from models import *
#
#class AnonymousQuestionAdmin(admin.ModelAdmin):
#    """AnonymousQuestion admin class"""
#
#class NodeAdmin(admin.ModelAdmin):
#    """Question admin class"""
#
#class TagAdmin(admin.ModelAdmin):
#    """Tag admin class"""
#
#class Answerdmin(admin.ModelAdmin):
#    """Answer admin class"""
#
#class CommentAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class VoteAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class FlaggedItemAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class FavoriteQuestionAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class QuestionRevisionAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class AnswerRevisionAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class AwardAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class BadgeAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class ReputeAdmin(admin.ModelAdmin):
#    """  admin class"""
#
#class ActionAdmin(admin.ModelAdmin):
#    """  admin class"""
    
#class BookAdmin(admin.ModelAdmin):
#    """  admin class"""
    
#class BookAuthorInfoAdmin(admin.ModelAdmin):
#    """  admin class"""
    
#class BookAuthorRssAdmin(admin.ModelAdmin):
#    """  admin class"""
    
#admin.site.register(Node, NodeAdmin)
#admin.site.register(Tag, TagAdmin)
#admin.site.register(QuestionRevision, QuestionRevisionAdmin)
#admin.site.register(AnswerRevision, AnswerRevisionAdmin)
#admin.site.register(Badge, BadgeAdmin)
#admin.site.register(Award, AwardAdmin)
#admin.site.register(Action, ActionAdmin)
#admin.site.register(Book, BookAdmin)
#admin.site.register(BookAuthorInfo, BookAuthorInfoAdmin)
#admin.site.register(BookAuthorRss, BookAuthorRssAdmin)
