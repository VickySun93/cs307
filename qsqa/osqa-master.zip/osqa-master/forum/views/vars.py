ON_SIGNIN_SESSION_ATTR = 'on_signin_url'
PENDING_SUBMISSION_SESSION_ATTR = 'pending_submission_data'
