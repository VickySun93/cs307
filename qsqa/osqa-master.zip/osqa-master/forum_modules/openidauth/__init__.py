try:
    import openid
    CAN_USE = True
except:
    CAN_USE = False