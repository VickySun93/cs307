DJANGO_APPS = ('djangosphinx', )

