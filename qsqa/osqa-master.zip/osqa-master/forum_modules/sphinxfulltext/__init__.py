try:
    import djangosphinx
    CAN_USE = True
except:
    CAN_USE = False