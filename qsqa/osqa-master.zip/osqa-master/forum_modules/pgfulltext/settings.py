from forum.settings.base import Setting

PG_FTSTRIGGERS_VERSION = Setting('PG_FTSTRIGGERS_VERSION', 0)