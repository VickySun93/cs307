from forum.settings.base import Setting

MYSQL_FTS_INSTALLED = Setting('MYSQL_FTS_INSTALLED', False)
MYSQL_FTS_VERSION = Setting('MYSQL_FTS_VERSION', 1)