try:
    import ldap
    CAN_USE = True
except:
    CAN_USE = False
